package se325.assignment01.concert.service.services;

public class ConcertResource {

    // TODO Implement this.

}
